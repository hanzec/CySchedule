package edu.iastate.coms309.springbootexperiment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootexperimentApplication {

    public static void main(String[] args) {

        SpringApplication.run(SpringbootexperimentApplication.class, args);
    }

}
