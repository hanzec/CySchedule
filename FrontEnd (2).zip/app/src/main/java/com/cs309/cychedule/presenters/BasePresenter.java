package com.cs309.cychedule.presenters;
/**
 * 这里存放业务逻辑, 所有于后端沟通的方法均解耦在这里
 * */
public class BasePresenter {
}
