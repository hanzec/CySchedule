package com.cs309.cychedule.models;

/**
 * 这里存放网络请求,数据封装,
 * 给后端预留回调接口
 * */

public class BaseModel {
}
