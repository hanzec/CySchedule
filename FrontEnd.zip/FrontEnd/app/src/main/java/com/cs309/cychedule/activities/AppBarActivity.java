package com.cs309.cychedule.activities;

import android.support.v7.app.AppCompatActivity;

public class AppBarActivity extends AppCompatActivity {
	// ...
}