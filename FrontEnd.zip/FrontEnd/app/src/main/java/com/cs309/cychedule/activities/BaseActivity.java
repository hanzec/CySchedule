package com.cs309.cychedule.activities;
import android.app.Activity;

/**
 * 这里存放UI逻辑, 只存放UI交互逻辑
 * */

public class BaseActivity extends Activity {

}
